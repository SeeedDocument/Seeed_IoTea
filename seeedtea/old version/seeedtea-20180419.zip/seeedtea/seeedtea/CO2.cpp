
#include "CO2.h"
#include <SoftwareSerial.h>
int CO2PPM;
int CO2_temp;

SoftwareSerial CO2_serial(4, 5);      // TX, RX

const unsigned char cmd_get_sensor[] =		//send data to CO2 Sensor
{
	0xff, 0x01, 0x86, 0x00, 0x00, 0x00, 0x00, 0x00, 0x79
};

void CO2_init(void) {
	CO2_serial.begin(9600);
}

bool CO2_dataRecieve(void)
{
    byte data[9];
    int i = 0;

    //transmit command data
    for(i=0; i<sizeof(cmd_get_sensor); i++)
    {
        CO2_serial.write(cmd_get_sensor[i]);
    }
    delay(10);
    //begin reveiceing data
    if(CO2_serial.available())
    {
        while(CO2_serial.available())
        {
            for(int i=0;i<9; i++)
            {
                data[i] = CO2_serial.read();
            }
        }
    }

    /*for(int j=0; j<9; j++)
    {
        SerialUSB.print(data[j]);
        SerialUSB.print(" ");
    }
    SerialUSB.println("");
    */
    if((i != 9) || (1 + (0xFF ^ (byte)(data[1] + data[2] + data[3] + data[4] + data[5] + data[6] + data[7]))) != data[8])
    {
        return false;
    }

    CO2PPM = (int)data[2] * 256 + (int)data[3];
    CO2_temp = (int)data[4] - 40;
    return true;
}



