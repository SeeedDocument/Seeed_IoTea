// 
// 
// 

#include "Dust_other.h"
//������Dust Sensor�ı���
//const int Dust_pin = 8;		//����

unsigned long duration;
unsigned long Dust_starttime;
const unsigned long sampletime_ms = 30000;//sampe 30s&nbsp;;
unsigned long lowpulseoccupancy = 0;
float ratio = 0;
float concentration = 0;
//������Dust Sensor�ı���

float Dust_concentration(void) {
	duration = pulseIn(Dust_pin, LOW);
	lowpulseoccupancy = lowpulseoccupancy + duration;
	if ((millis() - Dust_starttime) >= sampletime_ms)//if the sampel time = = 30s
	{
		ratio = lowpulseoccupancy / (sampletime_ms*10.0);  // Integer percentage 0=&gt;100
		concentration = 1.1*pow(ratio, 3) - 3.8*pow(ratio, 2) + 520 * ratio + 0.62; // using spec sheet curve
		lowpulseoccupancy = 0;
		Dust_starttime = millis();
		return concentration;
	}
	else
	{
		return 0;
	}
}

int O2_value(void) {
	long sum = 0;
	int out_val =0;
	double voltage = 2.58;	//У׼��ѹ
	for (int i = 0; i<32; i++)
	{
		sum += analogRead(O2_pin);
	}
	sum = sum / 32;
	out_val = sum*0.6768/voltage;
	return out_val;
}




