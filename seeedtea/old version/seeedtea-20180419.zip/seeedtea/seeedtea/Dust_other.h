// Dust_other.h

#ifndef _DUST_OTHER_h
#define _DUST_OTHER_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif
extern const int Dust_pin;
extern unsigned long Dust_starttime;
extern float Dust_concentration(void);



#endif

